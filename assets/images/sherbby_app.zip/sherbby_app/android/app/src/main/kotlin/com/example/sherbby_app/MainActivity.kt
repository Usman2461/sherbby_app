package com.example.sherbby_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
